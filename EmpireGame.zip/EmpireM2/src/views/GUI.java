package views;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import buildings.ArcheryRange;
import buildings.Barracks;
import buildings.Building;
import buildings.EconomicBuilding;
import buildings.Farm;
import buildings.Market;
import buildings.MilitaryBuilding;
import buildings.Stable;
import engine.City;
import engine.Game;
import exceptions.BuildingInCoolDownException;
import exceptions.FriendlyCityException;
import exceptions.FriendlyFireException;
import exceptions.MaxCapacityException;
import exceptions.MaxLevelException;
import exceptions.MaxRecruitedException;
import exceptions.NotEnoughGoldException;
import exceptions.TargetNotReachedException;
import units.Archer;
import units.Army;
import units.Cavalry;
import units.Infantry;
import units.Status;
import units.Unit;

public class GUI extends JFrame implements ActionListener {
	private JButton Start ; 
	private JLabel cairol ; 
	private JLabel spartal ; 
	private JLabel romel ;
	private JTextField playerName ;
	private JLabel choose ;
	private JLabel chooseC ;
	private JLabel rome ; 
	private JLabel cairo ; 
    private JLabel sparta ;
    private JLabel logo ;
    private JPanel startScreen ;
    private JFrame frame ;
    private JPanel mapview ;
    private JLabel romeI ; 
	private JLabel cairoI ; 
    private JLabel spartaI ;
    private JButton cairoB ;
    private JButton spartaB ;
    private JButton romeB ;
    private JRadioButton cairoRB ;
    private JRadioButton romeRB ;
    private JRadioButton spartaRB ;
    private JComboBox ControlledArmies ;
    private JLabel CA;
    private JTextArea resources ; 
    private Game game ;
    private String cityName ;
    private String Player ; 
    private JButton endTurn ;
    private JTextArea CAinfo ; 
    private JComboBox CAUinfo ; 
    private JTextArea CAinfo2 ; 
    private JTextArea CAinfo3 ; 
    private JButton relocateMV ; 
    private JButton target ;
    private JButton laysiege ; 
    private JButton autoresolve ;
    private JButton attack ; 
    
    private JPanel AorA ;
    private JButton AttackAorA;
    private JButton AutoAorA ;
    
    private JPanel battleview;
    private JComboBox ca ;
    private JComboBox da ;
    private JButton attackbv ;
    public  JLabel vs;
    public JLabel bvb ;
    
    private JPanel targetP ;
    private JButton targetB; 
    private JComboBox targetC ; 
    private JButton  targetX;
    
    private JPanel relocate;
    private JButton relocateB; 
    private JComboBox relocateC ; 
    private JButton  relocateX;
    
    private JPanel relocateCA;
    private JButton relocateBCA; 
    private JComboBox relocateCCA ; 
    private JButton  relocateXCA;
    private JButton relocateCV ;
    
    private JPanel relocateRO;
    private JButton relocateBRO; 
    private JComboBox relocateCRO ; 
    private JButton  relocateXRO;
    private JButton relocateRV ;
    
    private JPanel relocateSP;
    private JButton relocateBSP; 
    private JComboBox relocateCSP ; 
    private JButton  relocateXSP;
    private JButton relocateSV ;
    
    private JPanel cairoview ; 
    private JTextArea resourcesC ;
    private String lastCity ; 
    private String lastB ;
    private JRadioButton BarracksC ;
    private JRadioButton StableC ;
    private JRadioButton FarmC ;
    private JRadioButton MarketC ;
    private JRadioButton ArcheryRangeC ;
    private JButton BuildMBC ;
    private JButton RecruitMBC ;
    private JButton UpgradeMBC ;
    private JButton BackFromCairo ;
    private JLabel cairoBanner ;
    private JTextArea MilInfoC ;
    private JButton BuildEBC ;
    private JButton UpgradeEBC ;
    private JTextArea EcoInfoC ;
    private JComboBox defendingArmyC ;
    private JLabel DAC ;
    private JButton IAC ;
    private JComboBox CAIC;
    private JComboBox CAICinfo ;
    private JLabel CAICL ;
    private ArrayList<Army> AIC ;
    
    private JPanel romeview ; 
    private JTextArea resourcesR ;
    private JRadioButton BarracksR ;
    private JRadioButton StableR ;
    private JRadioButton FarmR ;
    private JRadioButton MarketR ;
    private JRadioButton ArcheryRangeR ;
    private JButton BuildMBR ;
    private JButton RecruitMBR ;
    private JButton UpgradeMBR ;
    private JButton BackFromRome ;
    private JLabel romeBanner ;
    private JTextArea MilInfoR ;
    private JButton BuildEBR ;
    private JButton UpgradeEBR ;
    private JTextArea EcoInfoR ;
    private JComboBox defendingArmyR ;
    private JLabel DAR ;
    private JButton IAR ;
    private JComboBox CAIR;
    private JComboBox CAIRinfo ;
    private JLabel CAIRL ;
    private ArrayList<Army> AIR ;
    
    
    private JPanel spartaview ; 
    private JTextArea resourcesS ;
    private JRadioButton BarracksS ;
    private JRadioButton StableS ;
    private JRadioButton FarmS ;
    private JRadioButton MarketS ;
    private JRadioButton ArcheryRangeS ;
    private JButton BuildMBS ;
    private JButton RecruitMBS ;
    private JButton UpgradeMBS ;
    private JButton BackFromSparta ;
    private JLabel spartaBanner ;
    private JTextArea MilInfoS ;
    private JButton BuildEBS ;
    private JButton UpgradeEBS ;
    private JTextArea EcoInfoS ;
    private JComboBox defendingArmyS ;
    private JLabel DAS ;
    private JButton IAS ;
    private JComboBox CAIS;
    private JComboBox CAISinfo ;
    private JLabel CAISL ;
    private ArrayList<Army> AIS ;
    
    
    private JPanel youwon ;
    private JPanel youlost ;
    private JLabel youwonl ;
    private JLabel youlostl;

    
    public GUI () {
    	
    	relocateB = new JButton ("Relocate");
    	relocateB.setBounds(200 , 75 ,100 , 50 );
    	relocateB.setBackground(Color.black);
    	relocateB.setForeground(Color.yellow);
    	relocateB.setVisible(true);
    	relocateB.addActionListener(this);
    	
    	relocateC = new JComboBox();
    	relocateC.setBounds(200,50,100,25);
    	relocateC.setBackground(Color.black);
    	relocateC.setForeground(Color.yellow);
    	relocateC.setVisible(true);
    	relocateC.addActionListener(this);
    	relocateC.setEditable(false);
    	
    	
    	relocateX = new JButton ("Cancel");
    	relocateX.setBounds(200 , 125 ,100 , 65 );
    	relocateX.setBackground(Color.black);
    	relocateX.setForeground(Color.yellow);
    	relocateX.setVisible(true);
    	relocateX.addActionListener(this);
    	
    	relocate = new JPanel();
    	relocate.setSize(500,250);
    	relocate.setVisible(false);
    	relocate.setBackground(Color.black);
    	relocate.add(relocateB);
    	relocate.add(relocateC);
    	relocate.setBounds(80,110,500,250);
    	relocate.setLayout(null);
    	relocate.add(relocateX);
    	
    	
    	
    	
    	
	
	   Start = new JButton ("Start",new ImageIcon("start.jpg"));
	   Start.setBounds(659,625,163,71);
	   Start.setVisible(true);
	   Start.addActionListener(this);
	   
	   cairol = new JLabel (new ImageIcon("clogo.png"));
	   cairol.setBounds(1200,360,183,71);
	   cairol.setVisible(true);
	   
	   
	   
	   romel = new JLabel (new ImageIcon("rlogo.jpg"));
	   romel.setBounds(1200,460,183,71);
	   romel.setVisible(true);
	   
	   
	   
	   spartal = new JLabel (new ImageIcon("slogo.jpg"));
	   spartal.setBounds(1200,560,183,71);
	   spartal.setVisible(true);
	   
	   cairoRB = new JRadioButton ();
	   cairoRB.setBounds(1100,390,30,50);
	   cairoRB.setVisible(true);
	   cairoRB.addActionListener(this);
	   cairoRB.setBackground(Color.black);
	   
	   romeRB = new JRadioButton ();
	   romeRB.setBounds(1100,490,30,50);
	   romeRB.setVisible(true);
	   romeRB.addActionListener(this);
	   romeRB.setBackground(Color.black);
	   
	   spartaRB = new JRadioButton ();
	   spartaRB.setBounds(1100,590,30,50);
	   spartaRB.setVisible(true);
	   spartaRB.addActionListener(this);
	   spartaRB.setBackground(Color.black);
	   
	   ButtonGroup cities = new ButtonGroup();
	   cities.add(cairoRB);
	   cities.add(romeRB);
	   cities.add(spartaRB);
	   
	   playerName = new JTextField("Player");
	   playerName.setVisible(true);
	   playerName.setBounds(150,300,200,50);
	   playerName.setBackground(Color.BLACK);
	   playerName.setFont((new Font("Serif", Font.PLAIN, 14 )));
       playerName.setForeground(Color.YELLOW);
       playerName.setHorizontalAlignment(JTextField.CENTER);
	   
	   choose = new JLabel(new ImageIcon("choose.jpeg"));
	   choose.setBounds(10, 200, 500, 88);
	   choose.setVisible(true);
	   
	   chooseC = new JLabel(new ImageIcon("chooseC.jpeg"));
	   chooseC.setBounds(1000, 200, 389, 88);
	   chooseC.setVisible(true);
	  
	   rome = new JLabel(new ImageIcon("rome.gif"));
	   rome.setBounds(1000, 450, 75, 90);
	   rome.setVisible(true);
	   
	   sparta = new JLabel(new ImageIcon("sparta.gif"));
	   sparta.setBounds(1000, 550, 75, 90);
	   sparta.setVisible(true);
	   
	   cairo = new JLabel(new ImageIcon("cairo.gif"));
	   cairo.setBounds(1000, 350, 75, 90);
	   cairo.setVisible(true);
	  
	   logo = new JLabel(new ImageIcon("logo.jpeg"));
	   logo.setBounds(500, -120, 500, 500);
	   logo.setVisible(true);
	   
	   
	   
	   startScreen = new JPanel();
	   startScreen.setBackground(Color.BLACK);
	   startScreen.setSize(1500,750);
	   startScreen.setVisible(true);
	   startScreen.setLayout(null);
	   startScreen.add(logo);
	   startScreen.add(Start);
	   startScreen.add(choose);
	   startScreen.add(playerName);
	   startScreen.add(rome);
	   startScreen.add(cairo);
	   startScreen.add(sparta);
	   startScreen.add(chooseC);
	   startScreen.add(cairol);
	   startScreen.add(romel);
	   startScreen.add(spartal);
	   startScreen.add(cairoRB);
	   startScreen.add(romeRB);
	   startScreen.add(spartaRB);
	   
	   
	   endTurn = new JButton("End Turn");
	   endTurn.setBounds(1350, 126, 150, 20);
	   endTurn.setVisible(true);
	   endTurn.addActionListener(this);
	   
	   
	   resources = new JTextArea();
	   resources.setBounds(1350,0,150,125);
	   resources.setVisible(true);
	   resources.setBackground(Color.black);
	   resources.setForeground(Color.yellow);
	   resources.setFont(new Font("Serif",Font.PLAIN,20));
	   resources.setEditable(false);
	  
       
       romeI = new JLabel(new ImageIcon("italy.jpg"));
	   romeI.setBounds(600, 40, 274, 473);
	   romeI.setVisible(true);
	   
	   
	   
	   cairoI = new JLabel(new ImageIcon("egypt.jpg"));
	   cairoI.setBounds(50, 375, 343, 317);
	   cairoI.setVisible(true);
	   
	   
	   spartaI = new JLabel(new ImageIcon("greece.jpg"));
	   spartaI.setBounds(1000, 330, 464, 380);
	   spartaI.setVisible(true);
	   
	   cairoB = new JButton("Cairo");
	   cairoB.setVisible(true);
	   cairoB.setBounds(106, 525, 200, 50);
	   cairoB.setBackground(Color.black);
	   cairoB.setForeground(Color.yellow);
	   cairoB.addActionListener(this);
	   
	   
	   romeB = new JButton("Rome");
	   romeB.setVisible(true);
	   romeB.setBounds(650, 150, 200, 50);
	   romeB.setBackground(Color.black);
	   romeB.setForeground(Color.yellow);
	   romeB.addActionListener(this);
	   
	   
	   spartaB = new JButton("Sparta");
	   spartaB.setVisible(true);
	   spartaB.setBounds(1100, 400, 200, 50);
	   spartaB.setBackground(Color.black);
	   spartaB.setForeground(Color.yellow);
	   spartaB.addActionListener(this);
	   
	   CA = new JLabel ("Controlled Armies");
       CA.setBounds(25, 25, 200, 80);
       CA.setBackground(Color.black);
       CA.setForeground(Color.yellow);
       CA.setFont(new Font("Serif",Font.PLAIN,20));
       CA.setVisible(true);
       
       
       
       
       ControlledArmies= new JComboBox ();
       ControlledArmies.setVisible(true);
       ControlledArmies.setBounds(25, 90, 100, 25);
       ControlledArmies.setBackground(Color.black);
       ControlledArmies.setForeground(Color.yellow);
       ControlledArmies.addActionListener(this);
	   
       CAUinfo= new JComboBox ();
       CAUinfo.setVisible(true);
       CAUinfo.setBounds(140, 90,  430, 25);
       CAUinfo.setBackground(Color.black);
       CAUinfo.setForeground(Color.yellow);
       CAUinfo.setEditable(false);
       
    
       CAinfo = new JTextArea();
       CAinfo.setBounds(25,130,150,25);
       CAinfo.setVisible(true);
       CAinfo.setBackground(Color.black);
       CAinfo.setForeground(Color.yellow);
       CAinfo.setFont(new Font("Serif",Font.PLAIN,20));
       CAinfo.setEditable(false);
       
       CAinfo2 = new JTextArea();
       CAinfo2.setBounds(200,130,150,25);
       CAinfo2.setVisible(true);
       CAinfo2.setBackground(Color.black);
       CAinfo2.setForeground(Color.yellow);
       CAinfo2.setFont(new Font("Serif",Font.PLAIN,16));
       CAinfo2.setEditable(false);
       
       CAinfo3 = new JTextArea();
       CAinfo3.setBounds(375,130,150,25);
       CAinfo3.setVisible(true);
       CAinfo3.setBackground(Color.black);
       CAinfo3.setForeground(Color.yellow);
       CAinfo3.setFont(new Font("Serif",Font.PLAIN,17));
       CAinfo3.setEditable(false);
       
       
       relocateMV = new JButton("Relocate");
       relocateMV.setVisible(true);
       relocateMV.setBounds(25,160,150,25);
       relocateMV.setBackground(Color.black);
       relocateMV.setForeground(Color.yellow);
       relocateMV.addActionListener(this);
       
       target = new JButton("Target");
       target.setVisible(true);
       target.setBounds(25,190,150,25);
       target.setBackground(Color.black);
       target.setForeground(Color.yellow);
       target.addActionListener(this);
       
       targetB = new JButton ("Target");
       targetB.setBounds(200 , 75 ,100 , 50 );
       targetB.setBackground(Color.black);
       targetB.setForeground(Color.yellow);
       targetB.setVisible(true);
       targetB.addActionListener(this);
   	
       targetC = new JComboBox();
       targetC.setBounds(200,50,100,25);
       targetC.setBackground(Color.black);
       targetC.setForeground(Color.yellow);
       targetC.setVisible(true);
       targetC.addActionListener(this);
       targetC.setEditable(false);
   	
   	
   	targetX = new JButton ("Cancel");
   	targetX.setBounds(200 , 125 ,100 , 65 );
   	targetX.setBackground(Color.black);
   	targetX.setForeground(Color.yellow);
   	targetX.setVisible(true);
   	targetX.addActionListener(this);
   	
   	targetP = new JPanel();
   	targetP.setSize(500,250);
   	targetP.setVisible(false);
   	targetP.setBackground(Color.black);
   	targetP.add(targetB);
   	targetP.add(targetC);
   	targetP.setBounds(80,110,500,250);
   	targetP.setLayout(null);
   	targetP.add(targetX);
   	
   	
   	laysiege = new JButton("Lay Siege");
    laysiege.setVisible(true);
    laysiege.setBounds(25,220,150,25);
    laysiege.setBackground(Color.black);
    laysiege.setForeground(Color.yellow);
    laysiege.addActionListener(this);
    
	autoresolve = new JButton("Auto Resolve");
    autoresolve.setVisible(true);
    autoresolve.setBounds(25,250,150,25);
    autoresolve.setBackground(Color.black);
    autoresolve.setForeground(Color.yellow);
    autoresolve.addActionListener(this);
    
	attack = new JButton("Battle");
    attack.setVisible(true);
    attack.setBounds(25,280,150,25);
    attack.setBackground(Color.black);
    attack.setForeground(Color.yellow);
    attack.addActionListener(this);
   	
       
	   mapview = new JPanel ();
       mapview.setVisible(false);
       mapview.setSize(1500,750);
       mapview.setBackground(Color.black);
       mapview.setLayout(null);
       mapview.add(romeI);
       mapview.add(cairoI);
       mapview.add(spartaI);
       mapview.add(cairoB);
       mapview.add(romeB);
       mapview.add(spartaB);
       mapview.add(resources);
       mapview.add(endTurn);
       mapview.add(ControlledArmies);
       mapview.add(CA);
       mapview.add(CAinfo);
       mapview.add(CAUinfo);
       mapview.add(CAinfo2);
       mapview.add(CAinfo3);
       mapview.add(relocateMV);
       mapview.add(relocate);
       mapview.add(target);
       mapview.add(targetP);
       mapview.add(laysiege);
       mapview.add(attack);
       mapview.add(autoresolve);
       
       resourcesC = new JTextArea();
	   resourcesC.setBounds(1350,0,150,125);
	   resourcesC.setVisible(true);
	   resourcesC.setBackground(Color.black);
	   resourcesC.setForeground(Color.yellow);
	   resourcesC.setFont(new Font("Serif",Font.PLAIN,20));
	   resourcesC.setEditable(false);
	   
	   BarracksC = new JRadioButton("Barracks");
	   BarracksC.setBounds(100,200,200,50);
	   BarracksC.setVisible(true);
	   BarracksC.setBackground(Color.black);
	   BarracksC.setForeground(Color.yellow);
	   BarracksC.setFont(new Font("Serif",Font.PLAIN,20));
	   BarracksC.addActionListener(this);
	   
	   StableC = new JRadioButton("Stable");
	   StableC.setBounds(100,252,200,50);
	   StableC.setVisible(true);
	   StableC.setBackground(Color.black);
	   StableC.setForeground(Color.yellow);
	   StableC.setFont(new Font("Serif",Font.PLAIN,20));
	   StableC.addActionListener(this);
	   
	   
	   ArcheryRangeC = new JRadioButton("Archery Range");
	   ArcheryRangeC.setBounds(100,302,200,50);
	   ArcheryRangeC.setVisible(true);
	   ArcheryRangeC.setBackground(Color.black);
	   ArcheryRangeC.setForeground(Color.yellow);
	   ArcheryRangeC.setFont(new Font("Serif",Font.PLAIN,20));
	   ArcheryRangeC.addActionListener(this);
	   
	   ButtonGroup CM = new ButtonGroup() ;
	   CM.add(ArcheryRangeC);
	   CM.add(BarracksC);
	   CM.add(StableC);
	   
	   FarmC = new JRadioButton("Farm");
	   FarmC.setBounds(400,200,200,50);
	   FarmC.setVisible(true);
	   FarmC.setBackground(Color.black);
	   FarmC.setForeground(Color.yellow);
	   FarmC.setFont(new Font("Serif",Font.PLAIN,20));
	   FarmC.addActionListener(this);
	   
	   MarketC = new JRadioButton("Market");
	   MarketC.setBounds(400,256,200,50);
	   MarketC.setVisible(true);
	   MarketC.setBackground(Color.black);
	   MarketC.setForeground(Color.yellow);
	   MarketC.setFont(new Font("Serif",Font.PLAIN,20));
	   MarketC.addActionListener(this);
	   
	   ButtonGroup EM = new ButtonGroup() ;
	   EM.add(MarketC);
	   EM.add(FarmC);
	   
	   
	   
	   BuildEBC = new JButton ("Build");
	   BuildEBC.setBounds(400,356,200,50);
	   BuildEBC.setVisible(true);
	   BuildEBC.setBackground(Color.black);
	   BuildEBC.setForeground(Color.yellow);
	   BuildEBC.addActionListener(this);
	   
	   
	   UpgradeEBC = new JButton ("Upgrade");
	   UpgradeEBC.setBounds(400,406,200,50);
	   UpgradeEBC.setVisible(true);
	   UpgradeEBC.setBackground(Color.black);
	   UpgradeEBC.setForeground(Color.yellow);
       UpgradeEBC.addActionListener(this);
	   
	   
	   
	   RecruitMBC = new JButton ("Recruit");
	   RecruitMBC.setBounds(100,460,200,50);
	   RecruitMBC.setVisible(true);
	   RecruitMBC.setBackground(Color.black);
	   RecruitMBC.setForeground(Color.yellow);
	   RecruitMBC.addActionListener(this);
	   
	   BuildMBC = new JButton ("Build");
	   BuildMBC.setBounds(100,400,200,50);
	   BuildMBC.setVisible(true);
	   BuildMBC.setBackground(Color.black);
	   BuildMBC.setForeground(Color.yellow);
	   BuildMBC.addActionListener(this);
	   
	   
	   UpgradeMBC = new JButton ("Upgrade");
	   UpgradeMBC.setBounds(100,520,200,50);
	   UpgradeMBC.setVisible(true);
	   UpgradeMBC.setBackground(Color.black);
	   UpgradeMBC.setForeground(Color.yellow);
	   UpgradeMBC.addActionListener(this);
       
       BackFromCairo = new JButton ("back");
       BackFromCairo.setBounds(0,0,200,50);
       BackFromCairo.setVisible(true);
       BackFromCairo.setBackground(Color.black);
       BackFromCairo.setForeground(Color.yellow);
       BackFromCairo.addActionListener(this);
       
       DAC = new JLabel ("Defending Army");
       DAC.setBounds(700, 150, 200, 80);
       DAC.setBackground(Color.black);
       DAC.setForeground(Color.yellow);
       DAC.setFont(new Font("Serif",Font.PLAIN,20));
       DAC.setVisible(true);
       
       
       
       
       defendingArmyC= new JComboBox ();
       defendingArmyC.setVisible(true);
       defendingArmyC.setBounds(700, 205, 500, 80);
       defendingArmyC.setBackground(Color.black);
       defendingArmyC.setForeground(Color.yellow);
       defendingArmyC.addActionListener(this);
       
       
       
       cairoBanner = new JLabel (new ImageIcon("cairobanner.jpeg"));
	   cairoBanner.setBounds(500,0,500,125);
	   cairoBanner.setVisible(true);
	   
	   
	   MilInfoC = new JTextArea();
	   MilInfoC.setBounds(1300,550,200,125);
	   MilInfoC.setVisible(true);
	   MilInfoC.setBackground(Color.black);
	   MilInfoC.setForeground(Color.yellow);
	   MilInfoC.setFont(new Font("Serif",Font.PLAIN,20));
	   MilInfoC.setEditable(false);
	   
	   EcoInfoC = new JTextArea();
	   EcoInfoC.setBounds(1100,550,200,125);
	   EcoInfoC.setVisible(true);
	   EcoInfoC.setBackground(Color.black);
	   EcoInfoC.setForeground(Color.yellow);
	   EcoInfoC.setFont(new Font("Serif",Font.PLAIN,20));
	   EcoInfoC.setEditable(false);
	   
	   IAC= new JButton ("Initiate Army");
	   IAC.setBounds(720,300,200,50);
	   IAC.setVisible(true);
	   IAC.setBackground(Color.black);
	   IAC.setForeground(Color.yellow);
	   IAC.addActionListener(this);
	   
	   
	   CAICinfo= new JComboBox ();
       CAICinfo.setVisible(true);
       CAICinfo.setBounds(810, 480,  430, 25);
       CAICinfo.setBackground(Color.black);
       CAICinfo.setForeground(Color.yellow);
       CAICinfo.setEditable(false);
	   
       
       CAIC= new JComboBox ();
       CAIC.setVisible(true);
       CAIC.setBounds(700, 480, 100, 25);
       CAIC.setBackground(Color.black);
       CAIC.setForeground(Color.yellow);
       CAIC.addActionListener(this);
       CAIC.setEditable(false);
       CAIC.addActionListener(this);
       
       
       CAICL = new JLabel ("Controlled Armies in Cairo");
       CAICL.setBounds(700, 380, 300, 80);
       CAICL.setBackground(Color.black);
       CAICL.setForeground(Color.yellow);
       CAICL.setFont(new Font("Serif",Font.PLAIN,20));
       CAICL.setVisible(true);
       
       
       
    relocateBCA = new JButton ("Relocate");
   	relocateBCA.setBounds(200 , 75 ,100 , 50 );
   	relocateBCA.setBackground(Color.black);
   	relocateBCA.setForeground(Color.yellow);
   	relocateBCA.setVisible(true);
   	relocateBCA.addActionListener(this);
   	
   	relocateCCA = new JComboBox();
   	relocateCCA.setBounds(200,50,100,25);
   	relocateCCA.setBackground(Color.black);
   	relocateCCA.setForeground(Color.yellow);
   	relocateCCA.setVisible(true);
   	relocateCCA.addActionListener(this);
   	relocateCCA.setEditable(false);
   	
   	
   	relocateXCA = new JButton ("Cancel");
   	relocateXCA.setBounds(200 , 125 ,100 , 65 );
   	relocateXCA.setBackground(Color.black);
   	relocateXCA.setForeground(Color.yellow);
   	relocateXCA.setVisible(true);
   	relocateXCA.addActionListener(this);
   	
   	relocateCA = new JPanel();
   	relocateCA.setSize(500,250);
   	relocateCA.setVisible(false);
   	relocateCA.setBackground(Color.black);
   	relocateCA.add(relocateBCA);
   	relocateCA.add(relocateCCA);
   	relocateCA.setBounds(1000,250,500,250);
   	relocateCA.setLayout(null);
   	relocateCA.add(relocateXCA);
   	
       relocateCV= new JButton ("Relocate");
       relocateCV.setBounds(950,300,200,50);
       relocateCV.setVisible(true);
       relocateCV.setBackground(Color.black);
       relocateCV.setForeground(Color.yellow);
       relocateCV.addActionListener(this);
   	
       
	   cairoview = new JPanel ();
	   cairoview.setSize(1500,750);
	   cairoview.setBackground(Color.black);
	   cairoview.setVisible(false);
	   cairoview.setLayout(null);
	   cairoview.add(resourcesC);
	   cairoview.add(BarracksC);
	   cairoview.add(StableC);
	   cairoview.add(ArcheryRangeC);
	   cairoview.add(BuildMBC);
	   cairoview.add(UpgradeMBC);
	   cairoview.add(RecruitMBC);
	   cairoview.add(BackFromCairo);
	   cairoview.add(cairoBanner);
	   cairoview.add(MilInfoC);
	   cairoview.add(FarmC);
	   cairoview.add(MarketC);
	   cairoview.add(BuildEBC);
	   cairoview.add(UpgradeEBC);
	   cairoview.add(EcoInfoC);
	   cairoview.add(defendingArmyC);
	   cairoview.add(DAC);
	   cairoview.add(IAC);
	   cairoview.add(CAIC);
	   cairoview.add(CAICinfo);
	   cairoview.add(CAICL);
	   cairoview.add(relocateCV);
	   cairoview.add(relocateCA);
	   
	   
	   
	   
	   
	   resourcesR = new JTextArea();
	   resourcesR.setBounds(1350,0,150,125);
	   resourcesR.setVisible(true);
	   resourcesR.setBackground(Color.black);
	   resourcesR.setForeground(Color.yellow);
	   resourcesR.setFont(new Font("Serif",Font.PLAIN,20));
	   resourcesR.setEditable(false);
	   
	   BarracksR = new JRadioButton("Barracks");
	   BarracksR.setBounds(100,200,200,50);
	   BarracksR.setVisible(true);
	   BarracksR.setBackground(Color.black);
	   BarracksR.setForeground(Color.yellow);
	   BarracksR.setFont(new Font("Serif",Font.PLAIN,20));
	   BarracksR.addActionListener(this);
	   
	   StableR = new JRadioButton("Stable");
	   StableR.setBounds(100,252,200,50);
	   StableR.setVisible(true);
	   StableR.setBackground(Color.black);
	   StableR.setForeground(Color.yellow);
	   StableR.setFont(new Font("Serif",Font.PLAIN,20));
	   StableR.addActionListener(this);
	   
	   
	   ArcheryRangeR = new JRadioButton("Archery Range");
	   ArcheryRangeR.setBounds(100,302,200,50);
	   ArcheryRangeR.setVisible(true);
	   ArcheryRangeR.setBackground(Color.black);
	   ArcheryRangeR.setForeground(Color.yellow);
	   ArcheryRangeR.setFont(new Font("Serif",Font.PLAIN,20));
	   ArcheryRangeR.addActionListener(this);
	   
	   ButtonGroup CMR = new ButtonGroup() ;
	   CMR.add(ArcheryRangeR);
	   CMR.add(BarracksR);
	   CMR.add(StableR);
	   
	   FarmR = new JRadioButton("Farm");
	   FarmR.setBounds(400,200,200,50);
	   FarmR.setVisible(true);
	   FarmR.setBackground(Color.black);
	   FarmR.setForeground(Color.yellow);
	   FarmR.setFont(new Font("Serif",Font.PLAIN,20));
	   FarmR.addActionListener(this);
	   
	   MarketR = new JRadioButton("Market");
	   MarketR.setBounds(400,256,200,50);
	   MarketR.setVisible(true);
	   MarketR.setBackground(Color.black);
	   MarketR.setForeground(Color.yellow);
	   MarketR.setFont(new Font("Serif",Font.PLAIN,20));
	   MarketR.addActionListener(this);
	   
	   ButtonGroup EMR = new ButtonGroup() ;
	   EMR.add(MarketR);
	   EMR.add(FarmR);
	   
	   
	   
	   BuildEBR = new JButton ("Build");
	   BuildEBR.setBounds(400,356,200,50);
	   BuildEBR.setVisible(true);
	   BuildEBR.setBackground(Color.black);
	   BuildEBR.setForeground(Color.yellow);
	   BuildEBR.addActionListener(this);
	   
	   
	   UpgradeEBR = new JButton ("Upgrade");
	   UpgradeEBR.setBounds(400,406,200,50);
	   UpgradeEBR.setVisible(true);
	   UpgradeEBR.setBackground(Color.black);
	   UpgradeEBR.setForeground(Color.yellow);
       UpgradeEBR.addActionListener(this);
	   
	   
	   
	   RecruitMBR = new JButton ("Recruit");
	   RecruitMBR.setBounds(100,460,200,50);
	   RecruitMBR.setVisible(true);
	   RecruitMBR.setBackground(Color.black);
	   RecruitMBR.setForeground(Color.yellow);
	   RecruitMBR.addActionListener(this);
	   
	   BuildMBR = new JButton ("Build");
	   BuildMBR.setBounds(100,400,200,50);
	   BuildMBR.setVisible(true);
	   BuildMBR.setBackground(Color.black);
	   BuildMBR.setForeground(Color.yellow);
	   BuildMBR.addActionListener(this);
	   
	   
	   UpgradeMBR = new JButton ("Upgrade");
	   UpgradeMBR.setBounds(100,520,200,50);
	   UpgradeMBR.setVisible(true);
	   UpgradeMBR.setBackground(Color.black);
	   UpgradeMBR.setForeground(Color.yellow);
	   UpgradeMBR.addActionListener(this);
       
       BackFromRome = new JButton ("back");
       BackFromRome.setBounds(0,0,200,50);
       BackFromRome.setVisible(true);
       BackFromRome.setBackground(Color.black);
       BackFromRome.setForeground(Color.yellow);
       BackFromRome.addActionListener(this);
       
       DAR = new JLabel ("Defending Army");
       DAR.setBounds(700, 150, 200, 80);
       DAR.setBackground(Color.black);
       DAR.setForeground(Color.yellow);
       DAR.setFont(new Font("Serif",Font.PLAIN,20));
       DAR.setVisible(true);
       
       
       
       
       defendingArmyR= new JComboBox ();
       defendingArmyR.setVisible(true);
       defendingArmyR.setBounds(700, 205, 500, 80);
       defendingArmyR.setBackground(Color.black);
       defendingArmyR.setForeground(Color.yellow);
       defendingArmyR.addActionListener(this);
      
       
       
       romeBanner = new JLabel (new ImageIcon("romebanner.jpeg"));
	   romeBanner.setBounds(500,0,500,125);
	   romeBanner.setVisible(true);
	   
	   
	   MilInfoR = new JTextArea();
	   MilInfoR.setBounds(1300,550,200,125);
	   MilInfoR.setVisible(true);
	   MilInfoR.setBackground(Color.black);
	   MilInfoR.setForeground(Color.yellow);
	   MilInfoR.setFont(new Font("Serif",Font.PLAIN,20));
	   MilInfoR.setEditable(false);
	   
	   EcoInfoR = new JTextArea();
	   EcoInfoR.setBounds(1100,550,200,125);
	   EcoInfoR.setVisible(true);
	   EcoInfoR.setBackground(Color.black);
	   EcoInfoR.setForeground(Color.yellow);
	   EcoInfoR.setFont(new Font("Serif",Font.PLAIN,20));
	   EcoInfoR.setEditable(false);
	   
	   IAR= new JButton ("Initiate Army");
	   IAR.setBounds(720,300,200,50);
	   IAR.setVisible(true);
	   IAR.setBackground(Color.black);
	   IAR.setForeground(Color.yellow);
	   IAR.addActionListener(this);
	   
	   
	   CAIRinfo= new JComboBox ();
       CAIRinfo.setVisible(true);
       CAIRinfo.setBounds(810, 480,  430, 25);
       CAIRinfo.setBackground(Color.black);
       CAIRinfo.setForeground(Color.yellow);
       CAIRinfo.setEditable(false);
	   
       
       CAIR= new JComboBox ();
       CAIR.setVisible(true);
       CAIR.setBounds(700, 480, 100, 25);
       CAIR.setBackground(Color.black);
       CAIR.setForeground(Color.yellow);
       CAIR.addActionListener(this);
       CAIR.setEditable(false);
       CAIR.addActionListener(this);
       
       
       CAIRL = new JLabel ("Controlled Armies in Rome");
       CAIRL.setBounds(700, 380, 300, 80);
       CAIRL.setBackground(Color.black);
       CAIRL.setForeground(Color.yellow);
       CAIRL.setFont(new Font("Serif",Font.PLAIN,20));
       CAIRL.setVisible(true);
	   
       relocateBRO = new JButton ("Relocate");
      	relocateBRO.setBounds(200 , 75 ,100 , 50 );
      	relocateBRO.setBackground(Color.black);
      	relocateBRO.setForeground(Color.yellow);
      	relocateBRO.setVisible(true);
      	relocateBRO.addActionListener(this);
      	
      	relocateCRO = new JComboBox();
      	relocateCRO.setBounds(200,50,100,25);
      	relocateCRO.setBackground(Color.black);
      	relocateCRO.setForeground(Color.yellow);
      	relocateCRO.setVisible(true);
      	relocateCRO.addActionListener(this);
      	relocateCRO.setEditable(false);
      	
      	
      	relocateXRO = new JButton ("Cancel");
      	relocateXRO.setBounds(200 , 125 ,100 , 65 );
      	relocateXRO.setBackground(Color.black);
      	relocateXRO.setForeground(Color.yellow);
      	relocateXRO.setVisible(true);
      	relocateXRO.addActionListener(this);
      	
      	relocateRO = new JPanel();
      	relocateRO.setSize(500,250);
      	relocateRO.setVisible(false);
      	relocateRO.setBackground(Color.black);
      	relocateRO.add(relocateBRO);
      	relocateRO.add(relocateCRO);
      	relocateRO.setBounds(1000,250,500,250);
      	relocateRO.setLayout(null);
      	relocateRO.add(relocateXRO);
      	
          relocateRV= new JButton ("Relocate");
          relocateRV.setBounds(950,300,200,50);
          relocateRV.setVisible(true);
          relocateRV.setBackground(Color.black);
          relocateRV.setForeground(Color.yellow);
          relocateRV.addActionListener(this);
       
	   
	   romeview = new JPanel ();
	   romeview.setSize(1500,750);
	   romeview.setBackground(Color.black);
	   romeview.setVisible(false);
	   romeview.setLayout(null);
	   romeview.add(resourcesR);
	   romeview.add(BarracksR);
	   romeview.add(StableR);
	   romeview.add(ArcheryRangeR);
	   romeview.add(BuildMBR);
	   romeview.add(UpgradeMBR);
	   romeview.add(RecruitMBR);
	   romeview.add(BackFromRome);
	   romeview.add(romeBanner);
	   romeview.add(MilInfoR);
	   romeview.add(FarmR);
	   romeview.add(MarketR);
	   romeview.add(BuildEBR);
	   romeview.add(UpgradeEBR);
	   romeview.add(EcoInfoR);
	   romeview.add(defendingArmyR);
	   romeview.add(DAR);
	   romeview.add(IAR);
	   romeview.add(CAIR);
	   romeview.add(CAIRinfo);
	   romeview.add(CAIRL);
	   romeview.add(relocateRV);
	   romeview.add(relocateRO);
	  
	   
	   resourcesS = new JTextArea();
	   resourcesS.setBounds(1350,0,150,125);
	   resourcesS.setVisible(true);
	   resourcesS.setBackground(Color.black);
	   resourcesS.setForeground(Color.yellow);
	   resourcesS.setFont(new Font("Serif",Font.PLAIN,20));
	   resourcesS.setEditable(false);
	   
	   BarracksS = new JRadioButton("Barracks");
	   BarracksS.setBounds(100,200,200,50);
	   BarracksS.setVisible(true);
	   BarracksS.setBackground(Color.black);
	   BarracksS.setForeground(Color.yellow);
	   BarracksS.setFont(new Font("Serif",Font.PLAIN,20));
	   BarracksS.addActionListener(this);
	   
	   StableS = new JRadioButton("Stable");
	   StableS.setBounds(100,252,200,50);
	   StableS.setVisible(true);
	   StableS.setBackground(Color.black);
	   StableS.setForeground(Color.yellow);
	   StableS.setFont(new Font("Serif",Font.PLAIN,20));
	   StableS.addActionListener(this);
	   
	   
	   ArcheryRangeS = new JRadioButton("Archery Range");
	   ArcheryRangeS.setBounds(100,302,200,50);
	   ArcheryRangeS.setVisible(true);
	   ArcheryRangeS.setBackground(Color.black);
	   ArcheryRangeS.setForeground(Color.yellow);
	   ArcheryRangeS.setFont(new Font("Serif",Font.PLAIN,20));
	   ArcheryRangeS.addActionListener(this);
	  
	   ButtonGroup CMS = new ButtonGroup() ;
	   CMS.add(ArcheryRangeS);
	   CMS.add(BarracksS);
	   CMS.add(StableS);
	   
	   FarmS = new JRadioButton("Farm");
	   FarmS.setBounds(400,200,200,50);
	   FarmS.setVisible(true);
	   FarmS.setBackground(Color.black);
	   FarmS.setForeground(Color.yellow);
	   FarmS.setFont(new Font("Serif",Font.PLAIN,20));
	   FarmS.addActionListener(this);
	  
	   MarketS = new JRadioButton("Market");
	   MarketS.setBounds(400,256,200,50);
	   MarketS.setVisible(true);
	   MarketS.setBackground(Color.black);
	   MarketS.setForeground(Color.yellow);
	   MarketS.setFont(new Font("Serif",Font.PLAIN,20));
	   MarketS.addActionListener(this);
	   
	   ButtonGroup EMS = new ButtonGroup() ;
	   EMS.add(MarketS);
	   EMS.add(FarmS);
	   
	   
	   
	   BuildEBS = new JButton ("Build");
	   BuildEBS.setBounds(400,356,200,50);
	   BuildEBS.setVisible(true);
	   BuildEBS.setBackground(Color.black);
	   BuildEBS.setForeground(Color.yellow);
	   BuildEBS.addActionListener(this);
	   
	   
	   UpgradeEBS = new JButton ("Upgrade");
	   UpgradeEBS.setBounds(400,406,200,50);
	   UpgradeEBS.setVisible(true);
	   UpgradeEBS.setBackground(Color.black);
	   UpgradeEBS.setForeground(Color.yellow);
       UpgradeEBS.addActionListener(this);
	   
	   
	   
	   RecruitMBS = new JButton ("Recruit");
	   RecruitMBS.setBounds(100,460,200,50);
	   RecruitMBS.setVisible(true);
	   RecruitMBS.setBackground(Color.black);
	   RecruitMBS.setForeground(Color.yellow);
	   RecruitMBS.addActionListener(this);
	  
	   BuildMBS = new JButton ("Build");
	   BuildMBS.setBounds(100,400,200,50);
	   BuildMBS.setVisible(true);
	   BuildMBS.setBackground(Color.black);
	   BuildMBS.setForeground(Color.yellow);
	   BuildMBS.addActionListener(this);
	  
	   
	   UpgradeMBS = new JButton ("Upgrade");
	   UpgradeMBS.setBounds(100,520,200,50);
	   UpgradeMBS.setVisible(true);
	   UpgradeMBS.setBackground(Color.black);
	   UpgradeMBS.setForeground(Color.yellow);
	   UpgradeMBS.addActionListener(this);
       
       BackFromSparta = new JButton ("back");
       BackFromSparta.setBounds(0,0,200,50);
       BackFromSparta.setVisible(true);
       BackFromSparta.setBackground(Color.black);
       BackFromSparta.setForeground(Color.yellow);
       BackFromSparta.addActionListener(this);
       
       DAS = new JLabel ("Defending Army");
       DAS.setBounds(700, 150, 200, 80);
       DAS.setBackground(Color.black);
       DAS.setForeground(Color.yellow);
       DAS.setFont(new Font("Serif",Font.PLAIN,20));
       DAS.setVisible(true);
       
       
       
       
       defendingArmyS= new JComboBox ();
       defendingArmyS.setVisible(true);
       defendingArmyS.setBounds(700, 205, 500, 80);
       defendingArmyS.setBackground(Color.black);
       defendingArmyS.setForeground(Color.yellow);
       defendingArmyS.addActionListener(this);
      
       
       
       spartaBanner = new JLabel (new ImageIcon("spartanBanner.jpeg"));
	   spartaBanner.setBounds(500,0,500,125);
	   spartaBanner.setVisible(true);
	   
	   
	   MilInfoS = new JTextArea();
	   MilInfoS.setBounds(1300,550,200,125);
	   MilInfoS.setVisible(true);
	   MilInfoS.setBackground(Color.black);
	   MilInfoS.setForeground(Color.yellow);
	   MilInfoS.setFont(new Font("Serif",Font.PLAIN,20));
	   MilInfoS.setEditable(false);
	   
	   EcoInfoS = new JTextArea();
	   EcoInfoS.setBounds(1100,550,200,125);
	   EcoInfoS.setVisible(true);
	   EcoInfoS.setBackground(Color.black);
	   EcoInfoS.setForeground(Color.yellow);
	   EcoInfoS.setFont(new Font("Serif",Font.PLAIN,20));
	   EcoInfoS.setEditable(false);
	   
	   
	   IAS= new JButton ("Initiate Army");
	   IAS.setBounds(720,300,200,50);
	   IAS.setVisible(true);
	   IAS.setBackground(Color.black);
	   IAS.setForeground(Color.yellow);
	   IAS.addActionListener(this);
	   
	   
	   CAISinfo= new JComboBox ();
       CAISinfo.setVisible(true);
       CAISinfo.setBounds(810, 480,  430, 25);
       CAISinfo.setBackground(Color.black);
       CAISinfo.setForeground(Color.yellow);
       CAISinfo.setEditable(false);
	   
       
       CAIS= new JComboBox ();
       CAIS.setVisible(true);
       CAIS.setBounds(700, 480, 100, 25);
       CAIS.setBackground(Color.black);
       CAIS.setForeground(Color.yellow);
       CAIS.addActionListener(this);
       CAIS.setEditable(false);
       CAIS.addActionListener(this);
       
       
       CAISL = new JLabel ("Controlled Armies in Sparta");
       CAISL.setBounds(700, 380, 300, 80);
       CAISL.setBackground(Color.black);
       CAISL.setForeground(Color.yellow);
       CAISL.setFont(new Font("Serif",Font.PLAIN,20));
       CAISL.setVisible(true);
	   
       
       relocateBSP = new JButton ("Relocate");
     	relocateBSP.setBounds(200 , 75 ,100 , 50 );
     	relocateBSP.setBackground(Color.black);
     	relocateBSP.setForeground(Color.yellow);
     	relocateBSP.setVisible(true);
     	relocateBSP.addActionListener(this);
     	
     	relocateCSP = new JComboBox();
     	relocateCSP.setBounds(200,50,100,25);
     	relocateCSP.setBackground(Color.black);
     	relocateCSP.setForeground(Color.yellow);
     	relocateCSP.setVisible(true);
     	relocateCSP.addActionListener(this);
     	relocateCSP.setEditable(false);
     	
     	
     	relocateXSP = new JButton ("Cancel");
     	relocateXSP.setBounds(200 , 125 ,100 , 65 );
     	relocateXSP.setBackground(Color.black);
     	relocateXSP.setForeground(Color.yellow);
     	relocateXSP.setVisible(true);
     	relocateXSP.addActionListener(this);
     	
     	relocateSP = new JPanel();
     	relocateSP.setSize(500,250);
     	relocateSP.setVisible(false);
     	relocateSP.setBackground(Color.black);
     	relocateSP.add(relocateBSP);
     	relocateSP.add(relocateCSP);
     	relocateSP.setBounds(1000,250,500,250);
     	relocateSP.setLayout(null);
     	relocateSP.add(relocateXSP);
     	
         relocateSV= new JButton ("Relocate");
         relocateSV.setBounds(950,300,200,50);
         relocateSV.setVisible(true);
         relocateSV.setBackground(Color.black);
         relocateSV.setForeground(Color.yellow);
         relocateSV.addActionListener(this);
       
	   spartaview = new JPanel ();
	   spartaview.setSize(1500,750);
	   spartaview.setBackground(Color.black);
	   spartaview.setVisible(false);
	   spartaview.setLayout(null);
	   spartaview.add(resourcesS);
	   spartaview.add(BarracksS);
	   spartaview.add(StableS);
	   spartaview.add(ArcheryRangeS);
	   spartaview.add(BuildMBS);
	   spartaview.add(UpgradeMBS);
	   spartaview.add(RecruitMBS);
	   spartaview.add(BackFromSparta);
	   spartaview.add(spartaBanner);
	   spartaview.add(MilInfoS);
	   spartaview.add(FarmS);
	   spartaview.add(MarketS);
	   spartaview.add(BuildEBS);
	   spartaview.add(UpgradeEBS);
	   spartaview.add(EcoInfoS);
	   spartaview.add(defendingArmyS);
	   spartaview.add(DAS);
	   spartaview.add(CAIS);
	   spartaview.add(CAISinfo);
	   spartaview.add(CAISL);
	   spartaview.add(IAS);
	   spartaview.add(relocateSV);
	   spartaview.add(relocateSP);
	  
	   ca = new JComboBox ();
	   ca.setBounds(250, 200, 450, 50);
	   ca.setBackground(Color.black);
	   ca.setForeground(Color.yellow);
	   ca.setEditable(false);
	   
	   
	   da = new JComboBox ();
	   da.setBounds(800, 200, 450, 50);
	   da.setBackground(Color.black);
	   da.setForeground(Color.yellow);
	   da.setEditable(false);
	   
	   
	   vs = new JLabel (new ImageIcon("vs.jpg"));
	   vs.setBounds(666,300, 178, 210);
	   vs.setVisible(true);
	   
	   bvb = new JLabel (new ImageIcon("bvb.png"));
	   bvb.setBounds(260,0, 937, 224);
	   bvb.setVisible(true);
	   
	   attackbv = new JButton (new ImageIcon("attack.png")) ;
	   attackbv.setBounds(630,550,270,90);
	   attackbv.setVisible(true);
	   attackbv.addActionListener(this);
	   
	   
	   
	   battleview = new JPanel ();
	   battleview.setSize(1500 , 750);
	   battleview.setBackground(Color.black);
	   battleview.add(vs);
	   battleview.add(ca);
	   battleview.add(da);
	   battleview.setLayout(null);
	   battleview.setVisible(false);
	   battleview.add(bvb);
	   battleview.add(attackbv);
	   
	   youwonl = new JLabel (new ImageIcon("youwon.jpg"));
	   youwonl.setBounds(350,0,800,800);
	   youwonl.setVisible(true);
	   
	   youwon = new JPanel();
	   youwon.setSize(1500,750);
	   youwon.setLayout(null);
	   youwon.setVisible(false);
	   youwon.add(youwonl);
	   youwon.setBackground(Color.black);
	   
	   
	   
	   youlostl = new JLabel (new ImageIcon("youlost.jpg"));
	   youlostl.setBounds(675,0,225,224);
	   youlostl.setVisible(true);
	   
	   youlost = new JPanel();
	   youlost.setSize(1500,750);
	   youlost.setLayout(null);
	   youlost.setVisible(false);
	   youlost.add(youlostl);
	   youlost.setBackground(Color.black);
	   
	   AttackAorA = new JButton ("Attack");
	   AttackAorA.setVisible(true);
	   AttackAorA.addActionListener(this);
	   AttackAorA.setBounds(175,100,100,100);
	   AttackAorA.setBackground(Color.black);
	   AttackAorA.setForeground(Color.yellow);
	   
	   AutoAorA = new JButton ("Auto Resolve");
	   AutoAorA.setVisible(true);
	   AutoAorA.addActionListener(this);
	   AutoAorA.setBounds(325,100,100,100);
	   AutoAorA.setBackground(Color.black);
	   AutoAorA.setForeground(Color.yellow);
	   
	   AorA = new JPanel ();
	   AorA.setSize( 1500, 750);
	   AorA.setVisible(false);
	   AorA.setBackground(Color.black);
	   AorA.add(AttackAorA);
	   AorA.add(AutoAorA);
	   
	   frame = new JFrame () ; 
	   frame.setVisible(true);
	   frame.setSize(1500,750);
	   frame.setTitle("Empire");
	   frame.setLayout(null);
	   frame.setBackground(Color.black);
	   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	   frame.add(startScreen);
	   frame.add(mapview);
	   frame.add(cairoview);
	   frame.add(romeview);
	   frame.add(spartaview);
	   frame.add(battleview);
	   frame.add(youlost);
	   frame.add(youwon);
	   frame.add(AorA);
	   
	   
	   
	   cityName="";
	   Player = "";
	   AIC = new ArrayList<Army>();
	   AIR = new ArrayList<Army>();
	   AIS = new ArrayList<Army>();
	
	   
	   
	  
   }
    
    public boolean maxturnsunderseige () {
    	for (int i = 0 ; i < game.getAvailableCities().size() ; i++) {
    		if( game.getAvailableCities().get(i).getTurnsUnderSiege()==3) {
    			return true ;
    		}
    	}
    	return false ;
    }
    
    public int getCityTUS (String a) {
    	int z = 0 ;
    	for (int i = 0 ; i < game.getAvailableCities().size() ; i ++) {
    		if(game.getAvailableCities().get(i).getName().equalsIgnoreCase(a)){
    			z = game.getAvailableCities().get(i).getTurnsUnderSiege();
    		}
    	}
    	return z ;
    }
    
    public void updateCACB (String b , JComboBox a){
    	String [] d = new String [game.getPlayer().getControlledArmies().size()];
    	for (int i = 0 ; i < game.getPlayer().getControlledArmies().size() ; i ++) {
    		if (game.getPlayer().getControlledArmies().get(i).getCurrentLocation().equalsIgnoreCase(b)) {
    			d[i] = d[i] = "Army"+( i + 1) ;
    		}
    	}
    	DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>(d);
    	a.setModel(model);
    	
    	
    }
    
    public void AICupdate(){
    	for (int i = 0 ; i < game.getPlayer().getControlledArmies().size() ; i++) {
    		if (game.getPlayer().getControlledArmies().get(i).getCurrentLocation().equalsIgnoreCase("Cairo"));{
    			AIC.add(game.getPlayer().getControlledArmies().get(i));
    		}
    		
    	}
    }
    
    public void AIRupdate(){
    	for (int i = 0 ; i < game.getPlayer().getControlledArmies().size() ; i++) {
    		if (game.getPlayer().getControlledArmies().get(i).getCurrentLocation().equalsIgnoreCase("Rome"));{
    			AIR.add(game.getPlayer().getControlledArmies().get(i));
    		}
    		
    	}
    }
    
    public void AISupdate(){
    	for (int i = 0 ; i < game.getPlayer().getControlledArmies().size() ; i++) {
    		if (game.getPlayer().getControlledArmies().get(i).getCurrentLocation().equalsIgnoreCase("Sparta"));{
    			AIS.add(game.getPlayer().getControlledArmies().get(i));
    		}
    		
    	}
    }
    
    public void UpdateCABV(int a , JComboBox c ) {
    	String [] b = new String [game.getPlayer().getControlledArmies().get(a).getUnits().size()];
    	Army x = game.getPlayer().getControlledArmies().get(a) ;
    	for (int i = 0 ; i < game.getPlayer().getControlledArmies().get(a).getUnits().size() ; i++ ) {
    		if(x.getUnits().get(i) instanceof Archer) {
    			b [i] = "Archer" + " " + "Level :"+ x.getUnits().get(i).getLevel()+" "+"Count :"+ x.getUnits().get(i).getCurrentSoldierCount() +" " + "Max Count :"+ x.getUnits().get(i).getMaxSoldierCount() ;
    		}
    		if(x.getUnits().get(i) instanceof Infantry) {
    			b[i] = "Infantry" + " " + "Level :"+ x.getUnits().get(i).getLevel()+" "+"Count :"+ x.getUnits().get(i).getCurrentSoldierCount() +" " + "Max Count :"+ x.getUnits().get(i).getMaxSoldierCount() ;
    		}
    		if(x.getUnits().get(i) instanceof Cavalry) {
    			b[i] = "Cavalry" + " " + "Level :"+ x.getUnits().get(i).getLevel()+" "+"Count :"+ x.getUnits().get(i).getCurrentSoldierCount() +" " + "Max Count :"+ x.getUnits().get(i).getMaxSoldierCount() ;
    		}
    	}
    	DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>(b);
    	c.setModel(model);
    }
    
    public void UpdateDABV (int a , JComboBox c) {
    	String [] b = new String [game.getAvailableCities().get(a).getDefendingArmy().getUnits().size()];
    	Army x = game.getAvailableCities().get(a).getDefendingArmy() ; 
    	for (int i = 0 ; i < x.getUnits().size() ; i ++) {
    		if(x.getUnits().get(i) instanceof Archer) {
    			b [i] = "Archer" + " " + "Level :"+ x.getUnits().get(i).getLevel()+" "+"Count :"+ x.getUnits().get(i).getCurrentSoldierCount() +" " + "Max Count :"+ x.getUnits().get(i).getMaxSoldierCount() ;
    		}
    		if(x.getUnits().get(i) instanceof Infantry) {
    			b[i] = "Infantry" + " " + "Level :"+ x.getUnits().get(i).getLevel()+" "+"Count :"+ x.getUnits().get(i).getCurrentSoldierCount() +" " + "Max Count :"+ x.getUnits().get(i).getMaxSoldierCount() ;
    		}
    		if(x.getUnits().get(i) instanceof Cavalry) {
    			b[i] = "Cavalry" + " " + "Level :"+ x.getUnits().get(i).getLevel()+" "+"Count :"+ x.getUnits().get(i).getCurrentSoldierCount() +" " + "Max Count :"+ x.getUnits().get(i).getMaxSoldierCount() ;
    		}
    	}
    	DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>(b);
    	c.setModel(model);
    			
    }
    
    public void updateCA(JComboBox c) {
    	
    	String [] a = new String [game.getPlayer().getControlledArmies().size()];
    	for (int i = 0 ; i < game.getPlayer().getControlledArmies().size() ; i++) {
    		a[i] = "Army"+( i + 1) ;
    	}
    	DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>(a);
    	c.setModel(model);
    }
    public void updateCAICinfo(int x , ArrayList<Army> a , JComboBox c){
    	String [] b = new String [a.get(x).getUnits().size()];
    	for (int i = 0 ; i < a.get(x).getUnits().size(); i++) {
    		if(a.get(x).getUnits().get(i) instanceof Archer) {
    			b [i] = "Archer" + " " + "Level :"+ a.get(x).getUnits().get(i).getLevel()+" "+"Count :"+ a.get(x).getUnits().get(i).getCurrentSoldierCount() +" " + "Max Count :"+ a.get(x).getUnits().get(i).getMaxSoldierCount() ;
    		}
    		if(a.get(x).getUnits().get(i) instanceof Infantry) {
    			b[i] = "Infantry" + " " + "Level :"+ a.get(x).getUnits().get(i).getLevel()+" "+"Count :"+ a.get(x).getUnits().get(i).getCurrentSoldierCount() +" " + "Max Count :"+ a.get(x).getUnits().get(i).getMaxSoldierCount() ;
    		}
    		if(a.get(x).getUnits().get(i) instanceof Cavalry) {
    			b[i] = "Cavalry" + " " + "Level :"+ a.get(x).getUnits().get(i).getLevel()+" "+"Count :"+ a.get(x).getUnits().get(i).getCurrentSoldierCount() +" " + "Max Count :"+ a.get(x).getUnits().get(i).getMaxSoldierCount() ;
    		}
    	}
    	 DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>(b);
    	 c.setModel(model);
    }
    
    public void updateCAInfo (int a ,JComboBox z ,  JTextArea s , JTextArea d , JTextArea p) {
    	 Army x = game.getPlayer().getControlledArmies().get(a);
    	 String [] b = new String [x.getUnits().size()];
    		 for (int i = 0 ; i < x.getUnits().size(); i++) {
    			 if(x.getUnits().get(i) instanceof Archer) {
    	    			b [i] = "Archer" + " " + "Level :"+ x.getUnits().get(i).getLevel()+" "+"Count :"+ x.getUnits().get(i).getCurrentSoldierCount() +" " + "Max Count :"+ x.getUnits().get(i).getMaxSoldierCount() ;
    	    		}
    	    		if(x.getUnits().get(i) instanceof Infantry) {
    	    			b[i] = "Infantry" + " " + "Level :"+ x.getUnits().get(i).getLevel()+" "+"Count :"+ x.getUnits().get(i).getCurrentSoldierCount() +" " + "Max Count :"+ x.getUnits().get(i).getMaxSoldierCount() ;
    	    		}
    	    		if(x.getUnits().get(i) instanceof Cavalry) {
    	    			b[i] = "Cavalry" + " " + "Level :"+ x.getUnits().get(i).getLevel()+" "+"Count :"+ x.getUnits().get(i).getCurrentSoldierCount() +" " + "Max Count :"+ x.getUnits().get(i).getMaxSoldierCount() ;
    	    		}
    		 }
    		 DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>(b);
        	 z.setModel(model);
        	 
        	 if(x.getCurrentStatus() == Status.IDLE ) {
        		 s.setText("Status: Idle");
        		 d.setText("Location: "+x.getCurrentLocation());
                 p.setVisible(false);        		
        		 
        	 }
        	 if(x.getCurrentStatus() == Status.MARCHING ) {
        		 s.setText("Status : Marching");
        		 d.setText("Target City:"+x.getTarget());
        		 p.setVisible(true);
        		 p.setText("Distance To Target: " +x.getDistancetoTarget());
        		 
        	 }
        	 if(x.getCurrentStatus() == Status.BESIEGING ) {
        		 s.setText("Status: Besieging");
        		 d.setText("Current Location: " + x.getCurrentLocation());
        		 p.setVisible(true);
        		 p.setText("Turns under Seige: "+getCityTUS(x.getCurrentLocation()));
        		 
        	 }
    	
    	 
    }
   
    public void UpdateAC(JComboBox a){
    	String [] b = new String [game.getAvailableCities().size()];
    	for(int i = 0 ; i < game.getAvailableCities().size() ; i++  ) {
    		b [i] = game.getAvailableCities().get(i).getName();
   	}
    	DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>(b);
   	 a.setModel(model);
    }
    
    
     public void updateDA (String a , JComboBox c ) {
    	City x = null ; 
    	for (int i = 0 ; i < game.getPlayer().getControlledCities().size();i++) {
    		if (game.getPlayer().getControlledCities().get(i).getName().equalsIgnoreCase(a)) {
    			x = game.getPlayer().getControlledCities().get(i);
    		}
    	}
    	String [] b = new String [x.getDefendingArmy().getUnits().size()];
    	for(int i = 0 ; i < b.length ; i++) {
    		int level = x.getDefendingArmy().getUnits().get(i).getLevel();
    		int maxc = x.getDefendingArmy().getUnits().get(i).getMaxSoldierCount();
    		int count = x.getDefendingArmy().getUnits().get(i).getCurrentSoldierCount();
    		if(x.getDefendingArmy().getUnits().get(i) instanceof Archer) {
    			b [i] = "Archer" + " " + "Level :"+ level+" "+"Count :"+count +" " + "Max Count :"+maxc ;
    		}
    		if(x.getDefendingArmy().getUnits().get(i) instanceof Infantry) {
    			b[i] = "Infantry" + " " + "Level :"+ level+" "+"Count :"+count + " " +"Max Count :"+maxc ;
    		}
    		if(x.getDefendingArmy().getUnits().get(i) instanceof Cavalry) {
    			b[i] = "Cavalry" + " " + "Level :"+ level+" "+"Count :"+count + " " +"Max Count :"+maxc ;
    		}
    				
    	}
    	DefaultComboBoxModel<String> model = new DefaultComboBoxModel<String>(b);
    	 c.setModel(model);
    	
    }
  
    public void updateResources (JTextArea a ) {
    	a.setText("Player:"+game.getPlayer().getName()+"\n"+"Gold :"+game.getPlayer().getTreasury()+"\n"+"Food:"+game.getPlayer().getFood()+"\n"+"Turn number :"+game.getCurrentTurnCount());
    }
    public Building getBuildingEI(String a , String b) {
    	City x = null;
    	EconomicBuilding z = null ;
    	for (int i = 0 ; i < game.getPlayer().getControlledCities().size();i++) {
    		if (game.getPlayer().getControlledCities().get(i).getName().equalsIgnoreCase(a)) {
    			x = game.getPlayer().getControlledCities().get(i);
    		}
    	}
    	for(int i = 0;  i < x.getEconomicalBuildings().size();i++) {
    		if (b.equals("Farm")&& x.getEconomicalBuildings().get(i) instanceof Farm) {
    			z=x.getEconomicalBuildings().get(i);
    		}
    		if (b.equals("Market")&& x.getEconomicalBuildings().get(i) instanceof Market) {
    			z=x.getEconomicalBuildings().get(i);
    		}
    		
    }
    	return z ;
    }
    public Building getBuildingMI(String a , String b) {
    	City x = null;
    	MilitaryBuilding z = null ;
    	for (int i = 0 ; i < game.getPlayer().getControlledCities().size();i++) {
    		if (game.getPlayer().getControlledCities().get(i).getName().equalsIgnoreCase(a)) {
    			x = game.getPlayer().getControlledCities().get(i);
    		}
    	}
    	for(int i = 0;  i < x.getMilitaryBuildings().size();i++) {
    		if (b.equals("Barracks")&& x.getMilitaryBuildings().get(i) instanceof Barracks) {
    			z=x.getMilitaryBuildings().get(i);
    		}
    		if (b.equals("ArcheryRange")&& x.getMilitaryBuildings().get(i) instanceof ArcheryRange) {
    			z=x.getMilitaryBuildings().get(i);
    		}
    		if (b.equals("Stable")&& x.getMilitaryBuildings().get(i) instanceof Stable) {
    			z=x.getMilitaryBuildings().get(i);
    		}
    }
    	return z ;
    }
    	
    
      public int getCityIndex(String a) {
    	  int x = 0 ;
    	  for (int i = 0 ; i < game.getPlayer().getControlledCities().size() ; i ++) {
    		  if (game.getPlayer().getControlledCities().get(i).getName().equalsIgnoreCase(a));
    		  x = i ;
    	  }
    	  return x ; 
	
}
      
      public int getCityIndexAC(String a) {
    	  int x = 0 ;
    	  for (int i = 0 ; i < game.getAvailableCities().size() ; i ++) {
    		  if (game.getAvailableCities().get(i).getName().equalsIgnoreCase(a));
    		  x = i ;
    	  }
    	  return x ; 
	
}
     public boolean  cityCheck(String a) {
    	for(int i = 0 ; i < game.getPlayer().getControlledCities().size() ; i++) {
    		if (game.getPlayer().getControlledCities().get(i).getName().equalsIgnoreCase(a)) {
    			return true;
    		}
    	}
    	return false ;
    }
    public void startgame (String a , String b) {
    	try {
			game = new Game (a , b);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
   
    public void updateMI (	String c , String a , JTextArea b) {
    	City x = null;
    	MilitaryBuilding z = null ;
    	for (int i = 0 ; i < game.getPlayer().getControlledCities().size();i++) {
    		if (game.getPlayer().getControlledCities().get(i).getName().equalsIgnoreCase(c)) {
    			x = game.getPlayer().getControlledCities().get(i);
    		}
    	}
    	for(int i = 0;  i < x.getMilitaryBuildings().size();i++) {
    		if (a.equals("Barracks")&& x.getMilitaryBuildings().get(i) instanceof Barracks) {
    			z=x.getMilitaryBuildings().get(i);
    		}
    		if (a.equals("ArcheryRange")&& x.getMilitaryBuildings().get(i) instanceof ArcheryRange) {
    			z=x.getMilitaryBuildings().get(i);
    		}
    		if (a.equals("Stable")&& x.getMilitaryBuildings().get(i) instanceof Stable) {
    			z=x.getMilitaryBuildings().get(i);
    		}
    	}
    	b.setText(a+" "+"Info :"+"\n"+"Level :"+z.getLevel()+"\n"+"Upgrade Cost :"+z.getUpgradeCost()+"\n"+"Recruitment Cost :"+z.getRecruitmentCost());
    }
    
    public void updateEI (	String c , String a , JTextArea b) {
    	City x = null;
    	EconomicBuilding z = null ;
    	for (int i = 0 ; i < game.getPlayer().getControlledCities().size();i++) {
    		if (game.getPlayer().getControlledCities().get(i).getName().equalsIgnoreCase(c)) {
    			x = game.getPlayer().getControlledCities().get(i);
    		}
    	}
    	for(int i = 0;  i < x.getEconomicalBuildings().size();i++) {
    		if (a.equals("Farm")&& x.getEconomicalBuildings().get(i) instanceof Farm) {
    			z=x.getEconomicalBuildings().get(i);
    		}
    		if (a.equals("Market")&& x.getEconomicalBuildings().get(i) instanceof Market) {
    			z=x.getEconomicalBuildings().get(i);
    		}
    		
    	}
    	b.setText(a+" "+"Info :"+"\n"+"Level :"+z.getLevel()+"\n"+"Upgrade Cost :"+z.getUpgradeCost());
    }
    
    public static void  main (String [] args) {
		new GUI();
		
    }

	
	@Override
	public void actionPerformed(ActionEvent e) {
	
		
		if ((e.getSource() == cairoRB)) {
		 cityName = "Cairo" ;
		 
		
		}
		
		if ((e.getSource() == romeRB)) {
			 cityName = "Rome" ;
			
		}
		
		
		if ((e.getSource() == spartaRB)) {
			 cityName = "Sparta" ;
			
		}
		
		
		if (e.getSource() == Start) {
			
			if (playerName.getText().equals("Player")) {
				JOptionPane.showMessageDialog(this, "Enter Your Name");
			}
			if(cityName.equals("")) {
				  JOptionPane.showMessageDialog(this, "Choose Your City");
			}
			else {
				startgame(playerName.getText(),cityName);
				startScreen.setVisible(false);
				mapview.setVisible(true);
				updateResources(resources);
				
				
			}			
			
		}
		if ((e.getSource() == endTurn)) {
			if(maxturnsunderseige()) {
				JOptionPane.showMessageDialog(this, "You have to take an action max turns under siege has been reached");
				AorA.setVisible(true);
				mapview.setVisible(false);
			}
			else if(game.isGameOver()) {
				if (game.getPlayer().getControlledCities().size() == 3) {
					mapview.setVisible(false);
					youwon.setVisible(true);
				}
				else {
					mapview.setVisible(false);
					youlost.setVisible(true);
				}
			}
			else {
			
			game.endTurn();
			updateResources(resources);
			updateCAInfo(ControlledArmies.getSelectedIndex() ,CAUinfo , CAinfo , CAinfo2 ,CAinfo3 );
		}
			}
		
		if  (e.getSource() == AttackAorA) {
			    AorA.setVisible(false);
				mapview.setVisible(false);
				battleview.setVisible(true);
				UpdateCABV(ControlledArmies.getSelectedIndex() , ca) ;
				UpdateDABV(targetC.getSelectedIndex() , da) ;
				
				
		}
		
		if(e.getSource() == AutoAorA) {
			int i = getCityIndexAC(game.getPlayer().getControlledArmies().get(ControlledArmies.getSelectedIndex()).getCurrentLocation());
			try {
				game.autoResolve(game.getPlayer().getControlledArmies().get(ControlledArmies.getSelectedIndex()), game.getAvailableCities().get(i).getDefendingArmy());
			} catch (FriendlyFireException e1) {
				JOptionPane.showMessageDialog(this, "Cannot Attack friendly city");
			}
			if (game.getPlayer().getControlledArmies().get(ControlledArmies.getSelectedIndex()).getUnits().size()==0) {
				JOptionPane.showMessageDialog(this, "You Lost");
			}
			else {
				JOptionPane.showMessageDialog(this, "You Won");
			}
			AorA.setVisible(false);
			mapview.setVisible(true);
			updateCAInfo(ControlledArmies.getSelectedIndex() ,CAUinfo , CAinfo , CAinfo2 ,CAinfo3 );
			
		}
		
		
		if(e.getSource() == cairoB ){
			if(cityCheck("Cairo")) {
			mapview.setVisible(false);
			cairoview.setVisible(true);
			updateResources(resourcesC);
			lastCity = "Cairo" ;
			updateDA(lastCity , defendingArmyC);
			updateCACB (lastCity , CAIC);
			updateCAICinfo(CAIC.getSelectedIndex(), AIC , CAICinfo);
			
		}
			else {
				JOptionPane.showMessageDialog(this, "Did not control yet");
			}
		}
		
		
		if(e.getSource() == romeB ){
			if(cityCheck("Rome")) {
			mapview.setVisible(false);
			romeview.setVisible(true);
			updateResources(resourcesR);
			lastCity = "Rome" ;
			updateDA(lastCity , defendingArmyR);
			updateCAICinfo(CAIR.getSelectedIndex(), AIR , CAIRinfo);
		}
			else {
				JOptionPane.showMessageDialog(this, "Did not control yet");
			}
		}
		
		
		if(e.getSource() == spartaB ){
			if(cityCheck("Sparta")) {
			mapview.setVisible(false);
			spartaview.setVisible(true);
			updateResources(resourcesS);
			lastCity = "Sparta" ;
			updateDA(lastCity , defendingArmyS);
			updateCAICinfo(CAIS.getSelectedIndex(), AIS , CAISinfo);
		}
			else {
				JOptionPane.showMessageDialog(this, "Did not control yet");
			}
		}
		
		if (e.getSource() == ControlledArmies) {
			updateCAInfo(ControlledArmies.getSelectedIndex() ,CAUinfo , CAinfo , CAinfo2 ,CAinfo3 );
		}
		
		if (e.getSource() == relocateMV) {
		    relocate.setVisible(true);
		    updateCA(relocateC);
		}
		if(e.getSource() == relocateB) {
			try {
				game.getPlayer().getControlledArmies().get(relocateC.getSelectedIndex()).relocateUnit(game.getPlayer().getControlledArmies().get(ControlledArmies.getSelectedIndex()).getUnits()
						.get(CAUinfo.getSelectedIndex()));
			} catch (MaxCapacityException e1) {
				JOptionPane.showMessageDialog(this, "Max Capacity Reached");
				
			}
			relocate.setVisible(false);
			updateCA(ControlledArmies);
			
		}
		
		if(e.getSource() == relocateX) {
			relocate.setVisible(false);
		}
		
		
		if (e.getSource() == target) {
			targetP.setVisible(true);
			UpdateAC(targetC);
		}
		
		if (e.getSource() == targetB) {
			updateCAInfo(ControlledArmies.getSelectedIndex() ,CAUinfo , CAinfo , CAinfo2 ,CAinfo3 );
			game.targetCity(game.getPlayer().getControlledArmies().get(ControlledArmies.getSelectedIndex()) , game.getAvailableCities().get(targetC.getSelectedIndex()).getName());
		    targetP.setVisible(false);
		
		}
		if(e.getSource() == targetX)
			targetP.setVisible(false);
		
		
		if (e.getSource()== laysiege) {
			try {
				game.getPlayer().laySiege(game.getPlayer().getControlledArmies().get(ControlledArmies.getSelectedIndex()), game.getAvailableCities().get(targetC.getSelectedIndex()));
				
			} catch (TargetNotReachedException e1) {
				JOptionPane.showMessageDialog(this, "Army not there yet");
			} catch (FriendlyCityException e1) {
				JOptionPane.showMessageDialog(this, "Cannot laysiege to friendly city");
			}
			updateCAInfo(ControlledArmies.getSelectedIndex() ,CAUinfo , CAinfo , CAinfo2 ,CAinfo3 );
			
		}
		
		
		if(e.getSource() == autoresolve) {
			int i = getCityIndexAC(game.getPlayer().getControlledArmies().get(ControlledArmies.getSelectedIndex()).getCurrentLocation());
			try {
				game.autoResolve(game.getPlayer().getControlledArmies().get(ControlledArmies.getSelectedIndex()), game.getAvailableCities().get(i).getDefendingArmy());
			} catch (FriendlyFireException e1) {
				JOptionPane.showMessageDialog(this, "Cannot Attack friendly city");
			}
			if (game.getPlayer().getControlledArmies().get(ControlledArmies.getSelectedIndex()).getUnits().size()==0) {
				JOptionPane.showMessageDialog(this, "You Lost");
			}
			else {
				JOptionPane.showMessageDialog(this, "You Won");
			}
			updateCAInfo(ControlledArmies.getSelectedIndex() ,CAUinfo , CAinfo , CAinfo2 ,CAinfo3 );
		}
		
		
		
		if(e.getSource()== attack) {
			if (game.getPlayer().getControlledArmies().get(ControlledArmies.getSelectedIndex()).getCurrentStatus() == Status.BESIEGING) {
			mapview.setVisible(false);
			battleview.setVisible(true);
			UpdateCABV(ControlledArmies.getSelectedIndex() , ca) ;
			UpdateDABV(targetC.getSelectedIndex() , da) ;
			
			}
			
		}
		
		
		if (e.getSource() == attackbv) {
			
			if (game.getPlayer().getControlledArmies().get(ControlledArmies.getSelectedIndex()).getUnits().size() == 0) {
				JOptionPane.showMessageDialog(this, "You Lost");
				battleview.setVisible(false);
				mapview.setVisible(true);
				updateResources(resources);
				updateCAInfo(ControlledArmies.getSelectedIndex() ,CAUinfo , CAinfo , CAinfo2 ,CAinfo3 );
			}
			if (game.getAvailableCities().get(targetC.getSelectedIndex()).getDefendingArmy().getUnits().size() == 0) {
				
				JOptionPane.showMessageDialog(this, "You won and you now Conquer "+ game.getPlayer().getControlledArmies().get(ControlledArmies.getSelectedIndex()).getCurrentLocation());
				battleview.setVisible(false);
				mapview.setVisible(true);
				updateCA(ControlledArmies);
				updateResources(resources);
				updateCAInfo(ControlledArmies.getSelectedIndex() ,CAUinfo , CAinfo , CAinfo2 ,CAinfo3 );
			    game.occupy(game.getPlayer().getControlledArmies().get(ControlledArmies.getSelectedIndex()), game.getAvailableCities().get(targetC.getSelectedIndex()).getName());
			    
			}
			else {
				Unit a = game.getPlayer().getControlledArmies().get(ControlledArmies.getSelectedIndex()).getUnits().get(ca.getSelectedIndex());
				Unit b = game.getAvailableCities().get(targetC.getSelectedIndex()).getDefendingArmy().getUnits().get(da.getSelectedIndex());
				try {
					a.attack(b);
					b.attack(a);
				} catch (FriendlyFireException e1) {
					JOptionPane.showMessageDialog(this, "Cannot Attack Friendly");
				}
			}
			UpdateCABV(ControlledArmies.getSelectedIndex() , ca) ;
			UpdateDABV(targetC.getSelectedIndex() , da) ;
		}
		//*****************************************************
		
		if(e.getSource() == BarracksC) {
			lastB = "Barracks"; 
			updateMI(lastCity , lastB , MilInfoC);
		}
		
		if(e.getSource() == StableC) {
			lastB = "Stable"; 
			updateMI(lastCity , lastB , MilInfoC);
		}
		
		if(e.getSource() == ArcheryRangeC) {
			lastB = "ArcheryRange"; 
			updateMI(lastCity , lastB , MilInfoC);
		}
		
		if (e.getSource()==MarketC) {
			lastB = "Market";
			updateEI(lastCity , lastB ,EcoInfoC );
		}
		
		if (e.getSource()==FarmC) {
			lastB = "Farm";
			updateEI(lastCity , lastB ,EcoInfoC );
		}
		if(e.getSource() == BuildMBC) {
			try {
				game.getPlayer().build(lastB, lastCity);
				updateResources(resourcesC);
				updateMI(lastCity , lastB ,MilInfoC );
			} catch (NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Not enough Gold");
			}
		
		}
		if(e.getSource() == BuildEBC) {
			try {
				game.getPlayer().build(lastB, lastCity);
				updateResources(resourcesC);
				updateEI(lastCity , lastB ,EcoInfoC );
			
			} catch (NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Not enough Gold");
			}
			}
		if(e.getSource() == RecruitMBC) {
			switch (lastB) {
			case "Barracks" : try {
					game.getPlayer().recruitUnit("Infantry", lastCity);
				} catch (BuildingInCoolDownException | MaxRecruitedException | NotEnoughGoldException e1) {
					JOptionPane.showMessageDialog(this, "Cannot Recruit");
				}break;
			case "Stable" : try {
				game.getPlayer().recruitUnit("Cavalry", lastCity);
			} catch (BuildingInCoolDownException | MaxRecruitedException | NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Cannot Recruit");
			}break;
			case "ArcheryRange" : try {
				game.getPlayer().recruitUnit("Archer", cityName);
			} catch (BuildingInCoolDownException | MaxRecruitedException | NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Cannot Recruit");
			}break;
			
			}
			 updateResources(resourcesC);
			 updateMI(lastCity , lastB , MilInfoC);
			 updateDA(lastCity , defendingArmyC );
		
		}
		if (e.getSource() == UpgradeMBC) {
			Building x = getBuildingMI(lastCity,lastB);
			
				try {
					game.getPlayer().upgradeBuilding(x);
					updateResources(resourcesC);
					updateMI(lastCity , lastB ,MilInfoC );
				} catch (NotEnoughGoldException e1) {
					JOptionPane.showMessageDialog(this, "Not enough Gold");
					e1.printStackTrace();
				} catch (BuildingInCoolDownException e1) {
					JOptionPane.showMessageDialog(this, "Building In cooldown");
					
				} catch (MaxLevelException e1) {
					JOptionPane.showMessageDialog(this, "Building Already Maxed");
				}
				
			
		}
		
		if (e.getSource() == UpgradeEBC) {
			Building x = getBuildingEI(lastCity,lastB);
			try {
				game.getPlayer().upgradeBuilding(x);
				updateResources(resourcesC);
				updateEI(lastCity , lastB ,EcoInfoC);
			} catch (NotEnoughGoldException | BuildingInCoolDownException | MaxLevelException e1) {
				
				JOptionPane.showMessageDialog(this, "Cannot Upgrade");
			}
		}
		
		if (e.getSource()== BackFromCairo) {
			cairoview.setVisible(false);
			mapview.setVisible(true);
			updateResources(resources);
		}
		
		
		if (e.getSource() == IAC ) {
			int IDA = defendingArmyC.getSelectedIndex();
			int CCI = getCityIndex(lastCity);
			game.getPlayer().initiateArmy(game.getPlayer().getControlledCities().get(CCI), game.getPlayer().getControlledCities().get(CCI).getDefendingArmy().getUnits().get(IDA));	
			updateCA(ControlledArmies);
			updateDA(lastCity , defendingArmyC );
			updateCACB (lastCity , CAIC);
			
		}
		if (e.getSource() == CAIC) {
			AICupdate();
			updateCAICinfo(CAIC.getSelectedIndex(), AIC , CAICinfo);
		}
		
		if(e.getSource()== relocateCV) {
			relocateCA.setVisible(true);
			updateCA(relocateCCA);
		}
		
		if(e.getSource() == relocateBCA) {
			int x = getCityIndex(lastCity);
		    try {
				game.getPlayer().getControlledArmies().get(relocateCCA.getSelectedIndex()).relocateUnit(game.getPlayer().getControlledCities().get(x).getDefendingArmy().getUnits().get(defendingArmyC.getSelectedIndex()));
			} catch (MaxCapacityException e1) {
				JOptionPane.showMessageDialog(this, "Max capacity Reached");
			}
		    updateDA(lastCity , defendingArmyC );
		    updateCA(ControlledArmies);
		}
		if (e.getSource() == relocateXCA) {
			relocateCA.setVisible(false);
		}
		
		//*************************
		
		if(e.getSource() == BarracksR) {
			lastB = "Barracks"; 
			updateMI(lastCity , lastB , MilInfoR);
		}
		
		if(e.getSource() == StableR) {
			lastB = "Stable"; 
			updateMI(lastCity , lastB , MilInfoR);
		}
		
		if(e.getSource() == ArcheryRangeR) {
			lastB = "ArcheryRange"; 
			updateMI(lastCity , lastB , MilInfoR);
		}
		
		if (e.getSource()==MarketR) {
			lastB = "Market";
			updateEI(lastCity , lastB ,EcoInfoR );
		}
		
		if (e.getSource()==FarmR) {
			lastB = "Farm";
			updateEI(lastCity , lastB ,EcoInfoR );
		}
		if(e.getSource() == BuildMBR) {
			try {
				game.getPlayer().build(lastB, lastCity);
				updateResources(resourcesR);
				updateMI(lastCity , lastB ,MilInfoR );
			} catch (NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Not enough Gold");
			}
		
		}
		if(e.getSource() == BuildEBR) {
			try {
				game.getPlayer().build(lastB, lastCity);
				updateResources(resourcesR);
				updateEI(lastCity , lastB ,EcoInfoR );
			
			} catch (NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Not enough Gold");
			}
			}
		if(e.getSource() == RecruitMBR) {
			switch (lastB) {
			case "Barracks" : try {
					game.getPlayer().recruitUnit("Infantry", lastCity);
				} catch (BuildingInCoolDownException | MaxRecruitedException | NotEnoughGoldException e1) {
					JOptionPane.showMessageDialog(this, "Cannot Recruit");
				}break;
			case "Stable" : try {
				game.getPlayer().recruitUnit("Cavalry", lastCity);
			} catch (BuildingInCoolDownException | MaxRecruitedException | NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Cannot Recruit");
			}break;
			case "ArcheryRange" : try {
				game.getPlayer().recruitUnit("Archer", cityName);
			} catch (BuildingInCoolDownException | MaxRecruitedException | NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Cannot Recruit");
			}break;
			
			}
			 updateResources(resourcesR);
			 updateMI(lastCity , lastB , MilInfoR);
			 updateDA(lastCity , defendingArmyR );
		
		}
		if (e.getSource() == UpgradeMBR) {
			Building x = getBuildingMI(lastCity,lastB);
			try {
				game.getPlayer().upgradeBuilding(x);
				updateResources(resourcesR);
				updateMI(lastCity , lastB ,MilInfoR );
			} catch (NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Not enough Gold");
				e1.printStackTrace();
			} catch (BuildingInCoolDownException e1) {
				JOptionPane.showMessageDialog(this, "Building In cooldown");
				
			} catch (MaxLevelException e1) {
				JOptionPane.showMessageDialog(this, "Building Already Maxed");
			}
			
		}
		
		if (e.getSource() == UpgradeEBR) {
			Building x = getBuildingEI(lastCity,lastB);
			try {
				game.getPlayer().upgradeBuilding(x);
				updateResources(resourcesR);
				updateEI(lastCity , lastB ,EcoInfoR);
			} catch (NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Not enough Gold");
				e1.printStackTrace();
			} catch (BuildingInCoolDownException e1) {
				JOptionPane.showMessageDialog(this, "Building In cooldown");
				
			} catch (MaxLevelException e1) {
				JOptionPane.showMessageDialog(this, "Building Already Maxed");
			}
			
		}
		
		if (e.getSource()== BackFromRome) {
			romeview.setVisible(false);
			mapview.setVisible(true);
			updateResources(resources);
		}
		if (e.getSource() == IAR ) {
			int IDA = defendingArmyR.getSelectedIndex();
			int CCI = getCityIndex(lastCity);
			game.getPlayer().initiateArmy(game.getPlayer().getControlledCities().get(CCI), game.getPlayer().getControlledCities().get(CCI).getDefendingArmy().getUnits().get(IDA));	
			updateCA(ControlledArmies);
			updateDA(lastCity , defendingArmyR );
			updateCACB (lastCity , CAIR);
			
		}
		if (e.getSource() == CAIR) {
			AIRupdate();
			updateCAICinfo(CAIR.getSelectedIndex(), AIR , CAIRinfo);
		}
		
		
		if(e.getSource()== relocateRV) {
			relocateRO.setVisible(true);
			updateCA(relocateCRO);
		}
		
		if(e.getSource() == relocateBRO) {
			int x = getCityIndex(lastCity);
		    try {
				game.getPlayer().getControlledArmies().get(relocateCRO.getSelectedIndex()).relocateUnit(game.getPlayer().getControlledCities().get(x).getDefendingArmy().getUnits().get(defendingArmyR.getSelectedIndex()));
			} catch (MaxCapacityException e1) {
				JOptionPane.showMessageDialog(this, "Max capacity Reached");
			}
		    updateDA(lastCity , defendingArmyR );
		    updateCA(ControlledArmies);
		    relocateRO.setVisible(false);
		}
		if(e.getSource() == relocateXRO) {
			relocateRO.setVisible(false);
		}
	
		//***************************************************
		
		if(e.getSource() == BarracksS) {
			lastB = "Barracks"; 
			updateMI(lastCity , lastB , MilInfoS);
		}
		
		if(e.getSource() == StableS) {
			lastB = "Stable"; 
			updateMI(lastCity , lastB , MilInfoS);
		}
		
		if(e.getSource() == ArcheryRangeS) {
			lastB = "ArcheryRange"; 
			updateMI(lastCity , lastB , MilInfoS);
		}
		
		if (e.getSource()==MarketS) {
			lastB = "Market";
			updateEI(lastCity , lastB ,EcoInfoS );
		}
		
		if (e.getSource()==FarmS) {
			lastB = "Farm";
			updateEI(lastCity , lastB ,EcoInfoS );
		}
		if(e.getSource() == BuildMBS) {
			try {
				game.getPlayer().build(lastB, lastCity);
				updateResources(resourcesS);
				updateMI(lastCity , lastB ,MilInfoS );
			} catch (NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Not enough Gold");
			}
		
		}
		if(e.getSource() == BuildEBS) {
			try {
				game.getPlayer().build(lastB, lastCity);
				updateResources(resourcesS);
				updateEI(lastCity , lastB ,EcoInfoS );
			
			} catch (NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Not enough Gold");
			}
			}
		if(e.getSource() == RecruitMBS) {
			switch (lastB) {
			case "Barracks" : try {
					game.getPlayer().recruitUnit("Infantry", lastCity);
				} catch (BuildingInCoolDownException | MaxRecruitedException | NotEnoughGoldException e1) {
					JOptionPane.showMessageDialog(this, "Cannot Recruit");
				}break;
			case "Stable" : try {
				game.getPlayer().recruitUnit("Cavalry", lastCity);
			} catch (BuildingInCoolDownException | MaxRecruitedException | NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Cannot Recruit");
			}break;
			case "ArcheryRange" : try {
				game.getPlayer().recruitUnit("Archer", cityName);
			} catch (BuildingInCoolDownException | MaxRecruitedException | NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Cannot Recruit");
			}break;
			
			}
			 updateResources(resourcesS);
			 updateMI(lastCity , lastB , MilInfoS);
			 updateDA(lastCity , defendingArmyS );
		
		}
		if (e.getSource() == UpgradeMBS) {
			Building x = getBuildingMI(lastCity,lastB);
			try {
				game.getPlayer().upgradeBuilding(x);
				updateResources(resourcesS);
				updateMI(lastCity , lastB ,MilInfoS );
			} catch (NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Not enough Gold");
				e1.printStackTrace();
			} catch (BuildingInCoolDownException e1) {
				JOptionPane.showMessageDialog(this, "Building In cooldown");
				
			} catch (MaxLevelException e1) {
				JOptionPane.showMessageDialog(this, "Building Already Maxed");
			}
			
		}
		
		if (e.getSource() == UpgradeEBS) {
			Building x = getBuildingEI(lastCity,lastB);
			try {
				game.getPlayer().upgradeBuilding(x);
				updateResources(resourcesS);
				updateEI(lastCity , lastB ,EcoInfoS);
			} catch (NotEnoughGoldException e1) {
				JOptionPane.showMessageDialog(this, "Not enough Gold");
				e1.printStackTrace();
			} catch (BuildingInCoolDownException e1) {
				JOptionPane.showMessageDialog(this, "Building In cooldown");
				
			} catch (MaxLevelException e1) {
				JOptionPane.showMessageDialog(this, "Building Already Maxed");
			}
			
		}
		
		if (e.getSource()== BackFromSparta) {
			spartaview.setVisible(false);
			mapview.setVisible(true);
			updateResources(resources);
		}
		if (e.getSource() == IAS ) {
			int IDA = defendingArmyS.getSelectedIndex();
			int CCI = getCityIndex(lastCity);
			game.getPlayer().initiateArmy(game.getPlayer().getControlledCities().get(CCI), game.getPlayer().getControlledCities().get(CCI).getDefendingArmy().getUnits().get(IDA));	
			updateCA(ControlledArmies);
			updateDA(lastCity , defendingArmyS);
			updateCACB (lastCity , CAIS);
			
		}
		if (e.getSource() == CAIS) {
			AISupdate();
			updateCAICinfo(CAIS.getSelectedIndex(), AIS , CAISinfo);
		}
		if(e.getSource()== relocateSV) {
			relocateSP.setVisible(true);
			updateCA(relocateCSP);
		}
		
		if(e.getSource() == relocateBSP) {
			int x = getCityIndex(lastCity);
		    try {
				game.getPlayer().getControlledArmies().get(relocateCSP.getSelectedIndex()).relocateUnit(game.getPlayer().getControlledCities().get(x).getDefendingArmy().getUnits().get(defendingArmyS.getSelectedIndex()));
			} catch (MaxCapacityException e1) {
				JOptionPane.showMessageDialog(this, "Max capacity Reached");
			}
		    updateDA(lastCity , defendingArmyS );
		    updateCA(ControlledArmies);
		    relocateSP.setVisible(false);
	
	}
		if(e.getSource() == relocateXSP) {
			relocateSP.setVisible(false);
		}
		
		
		}
	}

	
	

